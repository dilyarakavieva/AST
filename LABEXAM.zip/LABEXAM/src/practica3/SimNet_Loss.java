package practica3;

import java.util.Random;
import util.Const;
import util.Log;
import util.TCPSegment;

public class SimNet_Loss extends SimNet_Monitor {

    private double lossRate;
    private Random rand;
    private Log log;

    public SimNet_Loss(double lossRate) {
        this.lossRate = lossRate;
        rand = new Random(Const.SEED);
        log = Log.getLog();
    }

    //<-- no s'implementa l'atac!!
    @Override
    public void send(TCPSegment seg) {
        double a = rand.nextDouble();
        if (a > lossRate) {
            super.send(seg);
        } else {
            /*byte[] b = seg.getData();
            for (int i = 0; i < b.length/2; i++) {
                byte c = b[i];
                b[i] = b[b.length-1-i];
                b[b.length-1-i] = c;
                
            }
            seg.setData(b);*/
            //seg.setSourcePort(0);
            //super.send(seg);

            log.printRED("\t\t+++++++++ SEGMENTO MODIFICADO: " + seg + "+++++++++");
            super.send(seg);
        }
    }
}
