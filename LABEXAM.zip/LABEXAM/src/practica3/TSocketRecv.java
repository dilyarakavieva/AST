package practica3;

import util.Const;
import util.TCPSegment;
import util.TSocket_base;
import util.SimNet;

public class TSocketRecv extends TSocket_base {

    protected Thread thread;
    protected CircularQueue<TCPSegment> rcvQueue;
    protected int rcvSegConsumedBytes;

    public TSocketRecv(SimNet network) {
        super(network);
        rcvQueue = new CircularQueue<>(Const.RCV_QUEUE_SIZE);
        rcvSegConsumedBytes = 0;
        new ReceiverTask().start();
    }

    @Override
    public int receiveData(byte[] buf, int offset, int length) {
        lock.lock();
        try {
            int num = 0;
            while (this.rcvQueue.empty()) {
                this.appCV.awaitUninterruptibly();
            }
            
            while (num < length && !rcvQueue.empty()) {
                // modificamos length y buf para que sea como antes
                if( buf[0]== 0){//<-- fer-ho aquí no funciona.. s'ha de fer quan es rep el segment!!
                    /*for(int i = 1; i < length; i++ ){
                        buf[i--]= buf[i];
                        
                    }*/
                    //byte[] bufNou = new byte[length-1];
                    System.arraycopy(buf, 1, buf, offset, length);
                    length --;
                    System.out.println("hola");
                }
                
                num += this.consumeSegment(buf, offset + num, length - num);
            }
            return num;
        } finally {
            lock.unlock();
        }
    }

    protected int consumeSegment(byte[] buf, int offset, int length) {
        TCPSegment seg = rcvQueue.peekFirst();
        int a_agafar = Math.min(length, seg.getDataLength() - rcvSegConsumedBytes);
        System.arraycopy(seg.getData(), rcvSegConsumedBytes, buf, offset, a_agafar);
        rcvSegConsumedBytes += a_agafar;
        if (rcvSegConsumedBytes == seg.getDataLength()) {
            rcvQueue.get();
            rcvSegConsumedBytes = 0;
        }
        return a_agafar;
    }

    @Override
    public void processReceivedSegment(TCPSegment rseg) {
        lock.lock();
        try {
            if (!this.rcvQueue.full()) {
                
               /* byte[] bufCambia = rseg.getData();
                if(bufCambia[0] == 0)
                {
                    for(int i = 1; i < rseg.getDataLength(); i++)
                    {
                        bufCambia[i--] = bufCambia[i];
                    }
                    // aqui faltaria cambiar length
                    // lo que yo pensaba hacer es cambiar la data de segmento "quitar este 0"
                    //rseg.setData(bufCambia, 1, rseg.getDataLength()+1);
                    rseg.setData(bufCambia);
                }*/
                /*if(rseg.getData()[0] == 0)
                {
                    System.arraycopy(rseg.getData(), 1, rseg.getData(), 0, rseg.getDataLength());
                }*/
                if(rseg.getData()[0] == 0){
                    byte[] bufCambia = new byte[rseg.getDataLength()-1];
                    System.arraycopy(bufCambia, 1, rseg.getData(), 0, rseg.getDataLength());
                    rseg.setData(bufCambia);
                }
                this.rcvQueue.put(rseg);
                printRcvSeg(rseg);
                this.appCV.signal();
            }
        } finally {
            lock.unlock();
        }
    }

    class ReceiverTask extends Thread {

        @Override
        public void run() {
            while (true) {
                TCPSegment rseg = network.receive();
                processReceivedSegment(rseg);
            }
        }
    }
}
