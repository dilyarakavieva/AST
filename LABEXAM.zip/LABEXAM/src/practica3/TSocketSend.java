package practica3;

import util.TCPSegment;
import util.TSocket_base;
import util.SimNet;

public class TSocketSend extends TSocket_base {

    protected int MSS;       // Maximum Segment Size

    public TSocketSend(SimNet network) {
        super(network);
        MSS = 5;
    }

    
    
    @Override
    public void sendData(byte[] data, int offset, int length) {
        TCPSegment seg;
        int num = 0;
        // modificamos info de segmento
        //<-- s'hauria de fer per a cada segment i no modificar només un cop l'array de dades rebut!!
        byte[] dataNou = new byte[length + 1];
        dataNou[0] = 0;
        /*for (int i = 0; i < length; i++) {
            dataNou[i++] = data[i];
        }*/
        System.arraycopy(data, 0, dataNou, 1, length);
        length = length + 1;

        while (MSS < length) {
            seg = this.segmentize(dataNou, offset + num, MSS);
            num += MSS;
            length -= MSS;
        }
        if (MSS > length) {
            seg = this.segmentize(dataNou, offset + num, length);
        }
    }

    protected TCPSegment segmentize(byte[] data, int offset, int length) {
        TCPSegment seg = new TCPSegment();
        seg.setData(data, offset, length);
        seg.setPsh(true);
        printSndSeg(seg);
        network.send(seg);
        return seg;
    }

}
