package practica3;

import java.util.Iterator;
import util.Queue;

public class CircularQueue<E> implements Queue<E> {

    private final E[] queue;
    private final int N;//capacidad
    private int nelem;
    private int G;//head
    private int P;//tail

    public CircularQueue(int N) {
        this.N = N;
        queue = (E[]) (new Object[N]);
        G = 0;
        this.nelem = 0;
    }

    @Override
    public int size() {
        return nelem;
    }

    @Override
    public int free() {
        return N - size();
    }

    @Override
    public boolean empty() {
        return (size() == 0);
    }

    @Override
    public boolean full() {
        return (this.size() == N);
    }

    @Override
    public E peekFirst() {
        if (empty()) {
            return null;
        }
        return this.queue[G % N];
    }

    @Override
    public E get() {
        if (empty()) {
            throw new IllegalStateException("It is empty");
        }
        nelem--;
        G++;//<-- millor ja mantenir la G%N...
        return this.queue[(G - 1) % N];
    }

    @Override
    public void put(E e) {
        if (full()) {
            throw new IllegalStateException("It is full");
        }
        this.queue[(G + nelem) % N] = e;
        nelem++;

    }

    @Override
    public String toString() {
        String ast = new String();
        ast += "[";
        for (int i = 0; i < nelem - 1; i++) {
            ast += (this.queue[i] + ", ");
        }
        ast += this.queue[nelem - 1] + "]";
        return ast;
    }

    @Override
    public Iterator<E> iterator() {
        return new MyIterator();
    }

    class MyIterator implements Iterator {

        private int ite;

        @Override
        public boolean hasNext() {
            return (ite < nelem);// para ver si puede ir mas adelante
        }

        @Override
        public E next() {
            //ite = (1+ite)%N;
            ite++;// ite se cambia la posicion para mirar que pasa despues

            return queue[ite - 1];//para sacar el valor

        }

        @Override
        public void remove() {
            for (int i = ite - 1; i < nelem; i++) {

                queue[i] = queue[(i + 1) % N];// para cambiar la posicion en la cola

            }
            nelem--;// porque hemos quitado un elemento
            ite--;//para volver a la posicion donde estabamos

        }

    }
}
